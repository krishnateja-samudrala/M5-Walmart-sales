# M5-Forecasting-Accuracy
Problem statement: estimate, as precisely as possible, the point forecasts of the unit sales of various
products sold over a period of the next 28 days

transformed the time-series into a supervised learning dataset ; basic EDA , feature engineering is done.
Naive approaches and ensemble modelling used for training.

Custom Model WRMSSE score of 0.62229 on kaggle; in Top 4% on Kaggle Private Leaderboard.
Deployed on local-box and GCP App Engine (Flex).

Blog link: https://medium.com/@tarun99.m/m5-forecasting-accuracy-56e4c601e69c
